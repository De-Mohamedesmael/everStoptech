<div class="table-responsive">
    <table id="draft_table" class="table">
        <thead>
            <tr>
                <th>@lang('lang.date')</th>
                <th>@lang('lang.invoice_no')</th>
                <th>@lang('lang.value')</th>
                <th>@lang('lang.customer_type')</th>
                <th>@lang('lang.customer_name')</th>
                <th>@lang('lang.phone')</th>
                <th>@lang('lang.payment_type')</th>
                <th>@lang('lang.status')</th>
                <th>@lang('lang.delivery_man')</th>
                <th>@lang('lang.action')</th>
            </tr>
        </thead>
        <tbody>
        </tbody>
    </table>
</div>
